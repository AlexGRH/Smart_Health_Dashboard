import warnings
import flwr as fl
import numpy as np
import pandas as pd

# from sklearn.linear_model import SGDRegressor
from sklearn.metrics import explained_variance_score

from sklearn.metrics import mean_squared_log_error
from sklearn.ensemble import RandomForestRegressor
# from sklearn.neighbors import KNeighborsRegressor
# from sklearn.linear_model import LinearRegression
# from sklearn.neural_network import MLPRegressor
# from sklearn.svm import SVR
# from lightgbm import LGBMRegressor
from sklearn.metrics import mean_squared_error # for calculating the cost function

from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer
import sklearn.metrics as metrics
from sklearn.model_selection import TimeSeriesSplit

import utils

if __name__ == "__main__":
    # Load MNIST dataset from https://www.openml.org/d/554
    (X_train, y_train), (X_test, y_test) = utils.load_data("dailyActivity_merged.csv", single_user = True)
    # Split train set into 10 partitions and randomly use one for training.
#     (X_train, y_train) = utils.partition(X_train, y_train, 10)[partition_id]

    # # Create LogisticRegression Model
    # model = SGDRegressor(
    #    warm_start=True,  # prevent refreshing weights when fitting

    # Create RandomForestRegressor Model
    model = RandomForestRegressor(n_estimators=1000, n_jobs=-1, random_state=42, warm_start=True,)
    # Setting initial parameters, akin to model.compile for keras models
    #
    utils.set_initial_params(model)
    # Define Flower client
    class Client(fl.client.NumPyClient):
        def get_parameters(self):  # type: ignore
            return utils.get_model_parameters(model)

        def fit(self, parameters, config):
            print(X_train,y_train)
            model.fit(X_train, y_train)
            return utils.get_model_parameters(model), len(X_train), {}

        def evaluate(self, parameters, config):
            y_pred = model.predict(X_test)
            loss = float(format(np.sqrt(mean_squared_error(y_test, y_pred)),'.3f'))
            # print("\nRMSE:\n",rmse)
            accuracy = model.score(X_test, y_test)
            return loss, len(X_test), {"accuracy": accuracy}

        # def get_parameters(self):  # type: ignore
        #    return utils.get_model_parameters(model)
#
#         def fit(self, parameters, config):  # type: ignore
#             utils.set_model_params(model, parameters)
#             # Ignore convergence failure due to low local epochs
#             print(X_train,y_train)
# #             with warnings.catch_warnings():
# #                 warnings.simplefilter("ignore")
#             model.fit(X_train, y_train)
#             print(f"Training finished for round {config['rnd']}")
#             return utils.get_model_parameters(model), len(X_train), {}
#             # utils.get_model_parameters(model), len(X_train), {}
#
#         def evaluate(self, parameters, config):  # type: ignore
#             utils.set_model_params(model, parameters)
#             # loss = rmsle(y_test, model.predict(X_test))
#             loss = explained_variance_score(y_test, model.predict(X_test))
#             accuracy = model.score(X_test, y_test)
#             return loss, len(X_test), {"accuracy": accuracy}

    # Start Flower client
    fl.client.start_numpy_client("0.0.0.0:8080", client=Client())
