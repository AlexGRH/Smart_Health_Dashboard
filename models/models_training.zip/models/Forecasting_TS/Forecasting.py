import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_log_error
from sklearn.ensemble import RandomForestRegressor
from lightgbm import LGBMRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor
from sklearn.linear_model import SGDRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVR
import matplotlib.pyplot as plt


df = pd.read_csv('dailyActivity_merged.csv')
df['Date'] = pd.to_datetime(df['ActivityDate'])
df = df.sort_values(by="Date")
df['Day'] = df['Date'].dt.dayofyear
# print(df)
# df.to_csv('TS_data.csv')

#feature engineering
data_calories = df[['Id','Day','Calories']]

melt2 = data_calories.copy()
melt2['Yesterday'] = melt2.groupby(['Id'])['Calories'].shift()
melt2['Yesterday_Diff'] = melt2.groupby(['Id'])['Yesterday'].diff()
# melt2['Yesterday-1'] = melt2.groupby(['Id'])['Calories'].shift(2)
# melt2['Yesterday-1_Diff'] = melt2.groupby(['Id'])['Yesterday-1'].diff()
melt2 = melt2.dropna()

melt3 = melt2.join(df[['TotalSteps','TotalDistance','VeryActiveDistance','ModeratelyActiveDistance','LightActiveDistance','VeryActiveMinutes','FairlyActiveMinutes','LightlyActiveMinutes','SedentaryMinutes'
]])
melt3 = melt3.dropna()
print(melt3)


#Evaluating results with the RSMSE
def rmsle(ytrue, ypred):
    return np.sqrt(mean_squared_log_error(ytrue, ypred))

#Check Baseline error 0.45088 RMSE where we predict using yetserdays calories on todays
#Our score need to be 0.45 or better
mean_error = []
for day in range(124,133):
    train = melt2[melt2['Day'] < day]
    val = melt2[melt2['Day'] == day]

    p = val['Yesterday'].values

    error = rmsle(val['Calories'].values, p)
    print('Day %d - Error %.5f' % (day, error))
    mean_error.append(error)
print('Mean Error = %.5f' % np.mean(mean_error))

# The model
mean_error = []
for day in range(124,133):
    train = melt3[melt3['Day'] < day]
    val = melt3[melt3['Day'] == day]

    xtr, xts = train.drop(['Calories'], axis=1), val.drop(['Calories'], axis=1)
    ytr, yts = train['Calories'].values, val['Calories'].values

    #best model with score of 0.35
    # mdl = RandomForestRegressor(n_estimators=1000, n_jobs=-1, random_state=42)
    mdl = SGDRegressor()
# #     #0.44089
# #     # mdl = KNeighborsRegressor()
# #     #0.53862
# #     # mdl = SVR(gamma='auto')
# #     #0.80243
    # mdl = MLPRegressor(solver = 'lbfgs')
# #     #0.44384
# #     # mdl = LinearRegression()
# #     # mdl = LGBMRegressor(n_estimators=1000, learning_rate=0.01)
# #     # mdl.fit(xtr, np.log1p(ytr))
# #     # p = np.expm1(mdl.predict(xts))
    mdl.fit(xtr, ytr)
    p = mdl.predict(xts)
#
    error = rmsle(yts, p)
    print('Day %d - Error %.5f' % (day, error))
    mean_error.append(error)
print('Mean Error = %.5f' % np.mean(mean_error))

# plt.hist(melt3['Calories'], density=True, bins=30)  # density=False would make
# plt.show()

#GridSearch for RandomForestRegressor (still need to make it work!)

#     # model = RandomForestRegressor()
#     # param_search = {
#     # 'n_estimators': [200, 500, 1000],
#     # 'max_features': ['auto', 'sqrt', 'log2'],
#     # 'max_depth' : [i for i in range(5,15)],
#     # "bootstrap": [True, False]
#     # }
#     # # tscv = TimeSeriesSplit(n_splits=10)
#     # gsearch = GridSearchCV(estimator=model, cv=5, param_grid=param_search )
#     # gsearch.fit(xtr, ytr)
#     #
#     # best_score = gsearch.best_score_
#     # best_model = gsearch.best_estimator_
#     # # y_true = y_test.values
#     # p = best_model.predict(xts)
