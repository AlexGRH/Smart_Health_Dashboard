import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression


def get_model_parameters(model):
    """Returns the paramters of a sklearn LogisticRegression model."""
    if model.fit_intercept:
        params = (model.coef_, model.intercept_)
    else:
        params = (model.coef_,)
    return params

def load_data(path, partition = 'All'):
    dailyActivity = pd.read_csv(path)
    dailyActivity['ActivityDate'] = pd.to_datetime(dailyActivity.ActivityDate)

    train = dailyActivity[dailyActivity['ActivityDate'] <'2016-04-25']
    test = dailyActivity[dailyActivity['ActivityDate'] >='2016-04-25']
    


    # ids = train.Id.unique()
    # partition_id = np.random.choice(ids)
    if partition != 'All':
        if partition == 'first':
            partition_id = 1
        elif partition == "second":
            partition_id = 2
        train = train[train['PartitionID']==partition_id]
        test = test[test['PartitionID']==partition_id]
    
    X_train = np.array(train[['TotalSteps', 'VeryActiveMinutes', 'SedentaryMinutes', 'TotalMinutesAsleep', 'TotalMinutesAwake']])
    y_train = np.array(train['Class']).reshape(-1,)

    X_test = np.array(test[['TotalSteps', 'VeryActiveMinutes', 'SedentaryMinutes', 'TotalMinutesAsleep', 'TotalMinutesAwake']])
    y_test = np.array(test['Class']).reshape(-1,)
    
    return (X_train,y_train),(X_test,y_test)

def set_model_params(model, params):
    """Sets the parameters of a sklean LogisticRegression model."""
    model.coef_ = params[0]
    if model.fit_intercept:
        model.intercept_ = params[1]
    return model


def set_initial_params(model):
    """Sets initial parameters as zeros Required since model params are
    uninitialized until model.fit is called.

    But server asks for initial parameters from clients at launch. Refer
    to sklearn.linear_model.LogisticRegression documentation for more
    information.
    """
    n_classes = 2  # MNIST has 10 classes
    n_features = 5  # Number of features in dataset
    model.classes_ = np.array([i for i in range(10)])

    model.coef_ = np.zeros((n_classes, n_features))
    if model.fit_intercept:
        model.intercept_ = np.zeros((n_classes,))


# def load_mnist() -> Dataset:
#     """Loads the MNIST dataset using OpenML.

#     OpenML dataset link: https://www.openml.org/d/554
#     """
#     mnist_openml = openml.datasets.get_dataset(554)
#     Xy, _, _, _ = mnist_openml.get_data(dataset_format="array")
#     X = Xy[:, :-1]  # the last column contains labels
#     y = Xy[:, -1]
#     # First 60000 samples consist of the train set
#     x_train, y_train = X[:60000], y[:60000]
#     x_test, y_test = X[60000:], y[60000:]
#     return (x_train, y_train), (x_test, y_test)


# def shuffle(X: np.ndarray, y: np.ndarray) -> XY:
#     """Shuffle X and y."""
#     rng = np.random.default_rng()
#     idx = rng.permutation(len(X))
#     return X[idx], y[idx]


# def partition(X: np.ndarray, y: np.ndarray, num_partitions: int) -> XYList:
#     """Split X and y into a number of partitions."""
#     return list(
#         zip(np.array_split(X, num_partitions), np.array_split(y, num_partitions))
#     )
