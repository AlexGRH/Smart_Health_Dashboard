from typing import Tuple, Union, List
import numpy as np
import pandas as pd
# from sklearn.linear_model import SGDRegressor
import openml
from sklearn.model_selection import train_test_split

from sklearn.metrics import mean_squared_log_error
from sklearn.ensemble import RandomForestRegressor
# from sklearn.neighbors import KNeighborsRegressor
# from sklearn.linear_model import LinearRegression
# from sklearn.neural_network import MLPRegressor
# from sklearn.svm import SVR
# from lightgbm import LGBMRegressor

from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer
import sklearn.metrics as metrics
from sklearn.model_selection import TimeSeriesSplit

# XY = Tuple[np.ndarray, np.ndarray]
# Dataset = Tuple[XY, XY]
# LogRegParams = Union[XY, Tuple[np.ndarray]]
# XYList = List[XY]

#changed get_model_parameters only here and load_data
# def get_model_parameters(model):
#     # suppose this estimator has parameters "alpha" and "recursive"
#     params = model.get_params()
#     print(params)
#     return params

def get_model_parameters(model):
    if model.fit_intercept:
        params = (model.coef_, model.intercept_)
    else:
        params = (model.coef_,)
    return params

def set_model_params(model, params):
    model.coef_ = params[0]
    if model.fit_intercept:
        model.intercept_ = params[1]
        return model

def set_initial_params(model):
    n_classes = 1  # MNIST has 10 classes
    n_features = 9  # Number of features in dataset
#     model.classes_ = np.array([i for i in range(10)])

    model.coef_ = np.zeros((n_features,))
    if model.fit_intercept:
        model.intercept_ = np.zeros((n_classes,))

def load_data(path, single_user = False):

    #read in data and feature engineering
    df = pd.read_csv('dailyActivity_merged.csv')
    df['Date'] = pd.to_datetime(df['ActivityDate'])
    df = df.sort_values(by="Date")
    df['Day'] = df['Date'].dt.dayofyear


#feature engineering add Yesterdays calories (lag) and diff
    data_calories = df[['Id','Day','Calories']]
    melt2 = data_calories.copy()
    melt2['Yesterday'] = melt2.groupby(['Id'])['Calories'].shift()
    melt2['Yesterday_Diff'] = melt2.groupby(['Id'])['Yesterday'].diff()
# melt2['Yesterday-1'] = melt2.groupby(['Id'])['Calories'].shift(2)
# melt2['Yesterday-1_Diff'] = melt2.groupby(['Id'])['Yesterday-1'].diff()

#adding 'x' variables to predict calories
    melt2 = melt2.dropna()
    melt3 = melt2.join(df[['TotalSteps','TotalDistance','VeryActiveDistance','ModeratelyActiveDistance','LightActiveDistance','VeryActiveMinutes','FairlyActiveMinutes','LightlyActiveMinutes','SedentaryMinutes'
    ]])
    melt3 = melt3.dropna()
    # melt3.to_csv('TS_data.csv')

#split train and test 0.7/0.3 ratio
    train, test = train_test_split(melt3, test_size=0.3, shuffle=False)

    ids = train.Id.unique()
    partition_id = np.random.choice(ids)

    train = train[train['Id']==partition_id]
    test = test[test['Id']==partition_id]

    #from utils
    # X_train = np.array(train[['Calories','TotalDistance']])
    # y_train = np.array(train['TotalSteps']).reshape(-1,)
    # X_test = np.array(test[['Calories','TotalDistance']])
    # y_test = np.array(test['TotalSteps']).reshape(-1,)

    #predict on calories
    X_train, X_test = train.drop(['TotalSteps'], axis=1), test.drop(['TotalSteps'], axis=1)
    y_train, y_test = train['TotalSteps'].values, test['TotalSteps'].values

    return (X_train,y_train),(X_test,y_test)
