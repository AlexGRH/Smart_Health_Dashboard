import flwr as fl
import utils
from sklearn.metrics import explained_variance_score
# from sklearn.linear_model import SGDRegressor
from typing import Dict
import numpy as np
import pandas as pd
from joblib import dump

from sklearn.metrics import mean_squared_log_error
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.neighbors import KNeighborsRegressor
# from sklearn.linear_model import LinearRegression
# from sklearn.neural_network import MLPRegressor
# from sklearn.svm import SVR
# from lightgbm import LGBMRegressor
from sklearn.metrics import mean_squared_error

from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer
import sklearn.metrics as metrics
from sklearn.model_selection import TimeSeriesSplit



def fit_round(rnd: int) -> Dict:
    """Send round number to client."""
    return {"rnd": rnd}


def get_eval_fn(model):
    """Return an evaluation function for server-side evaluation."""

    # Load test data here to avoid the overhead of doing it in `evaluate` itself
    _, (X_test, y_test) = utils.load_data("dailyActivity_merged.csv")

    # The `evaluate` function will be called after every round
    def evaluate(parameters: fl.common.Weights):
        # Update model with the latest parameters
        # utils.set_model_params(model, parameters)

        y_pred = model.predict(X_test)
        #For the RMSE score
        loss = float(format(np.sqrt(mean_squared_error(y_test, y_pred)),'.3f'))
        # loss = rmsle(y_test, model.predict(X_test))
        accuracy = model.score(X_test, y_test)
        dump(model, "LogReg.joblib")
        return loss, {"accuracy": accuracy}

    return evaluate


# Start Flower server for five rounds of federated learning
if __name__ == "__main__":
    model = RandomForestRegressor()
    # utils.set_initial_params(model)
    strategy = fl.server.strategy.FedAvg(
        min_available_clients=2,
        eval_fn=get_eval_fn(model),
        on_fit_config_fn=fit_round,
    )
    fl.server.start_server("0.0.0.0:8080", strategy=strategy, config={"num_rounds": 5})
